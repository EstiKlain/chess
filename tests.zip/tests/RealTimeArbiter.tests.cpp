#include "doctest.h"

#include "RealTimeArbiter.hpp"
#include "Board.hpp"


static pieceRules::PieceRulesRegistry registry;


namespace
{
    Board makeBoard(std::initializer_list<std::initializer_list<std::string>> rows)
    {
        Board b;
        for (const auto &row : rows)
        {
            b.grid.push_back(std::vector<std::string>(row.begin(), row.end()));
        }
        return b;
    }
}

TEST_CASE("is_piece_in_flight_matches_origin_square_state_during_move")
{
    // Why this matters: the origin square should be treated as occupied by an in-flight piece until the move lands, matching the current engine flow.
    // Arrange
    RealTimeArbiter arbiter;
    PieceMove m;
    m.fromRow = 0;
    m.fromCol = 0;
    m.toRow = 0;
    m.toCol = 3;
    m.startMs = 0;
    m.durationMs = 1000;
    m.piece = "wR";
    arbiter.startMotion(m);

    // Act / Assert
    CHECK(arbiter.isPieceInFlight(0, 0));
    CHECK_FALSE(arbiter.isPieceInFlight(0, 3));
}

TEST_CASE("hasActiveMotion is false when activeMoves is empty")
{
    RealTimeArbiter arbiter;
    CHECK_FALSE(arbiter.hasActiveMotion());
}

TEST_CASE("hasActiveMotion is true when a move is in flight")
{
    RealTimeArbiter arbiter;
    PieceMove m;
    m.fromRow = 0;
    m.fromCol = 0;
    m.toRow = 0;
    m.toCol = 1;
    m.startMs = 0;
    m.durationMs = 1000;
    m.piece = "wR";
    arbiter.startMotion(m);
    CHECK(arbiter.hasActiveMotion());
}

TEST_CASE("resolveMoves lands the piece at destination when duration expires")
{
    // Arrange: יוצרים לוח שבו הכלי wR יצא מ-(0,0) ונמצא בדרך ל-(0,2)
    Board b = makeBoard({{".", ".", "."}});
    RealTimeArbiter arbiter;
    PieceMove m;
    m.fromRow = 0;
    m.fromCol = 0;
    m.toRow = 0;
    m.toCol = 2;
    m.startMs = 0;
    m.durationMs = 500;
    m.piece = "wR";
    arbiter.startMotion(m);

    // נקבע שהזמן הנוכחי הוא 600ms (עבר את ה-500ms של משך התנועה)
    // Act
    arbiter.resolveMoves(b, 600 , registry);

    // Assert: המהלך היה צריך להסתיים
    CHECK_FALSE(arbiter.hasActiveMotion()); // תור התנועות התרוקן
    CHECK(b.grid[0][2] == "wR");            // הכלי נחת בהצלחה ביעד
}

TEST_CASE("white pawn promoted to queen on arrival at row 0")
{
    Board b = makeBoard({{"."}, {"wP"}});
    RealTimeArbiter arbiter;
    PieceMove m;
    m.fromRow = 1;
    m.fromCol = 0;
    m.toRow = 0;
    m.toCol = 0;
    m.startMs = 0;
    m.durationMs = 500;
    m.piece = "wP";
    arbiter.startMotion(m);

    arbiter.resolveMoves(b, 500, registry);

    CHECK(b.grid[0][0] == "wQ");
}

TEST_CASE("black pawn promoted to queen on arrival at last row")
{
    Board b = makeBoard({{"."}, {"."}, {"."}, {"."}, {"."}, {"."}, {"."}, {"."}});
    RealTimeArbiter arbiter;
    PieceMove m;
    m.fromRow = 6;
    m.fromCol = 0;
    m.toRow = 7;
    m.toCol = 0;
    m.startMs = 0;
    m.durationMs = 500;
    m.piece = "bP";
    arbiter.startMotion(m);

    arbiter.resolveMoves(b, 500, registry);

    CHECK(b.grid[7][0] == "bQ");
}

TEST_CASE("pawn arriving at non-promotion row remains a pawn")
{
    Board b = makeBoard({
        {".", ".", "."},
        {".", ".", "."},
        {".", ".", "."},
        {".", ".", "."},
        {".", ".", "."},
        {".", ".", "."},
        {"wP", ".", "."},
        {".", ".", "."}
    });
    RealTimeArbiter arbiter;
    PieceMove m;
    m.fromRow = 6;
    m.fromCol = 0;
    m.toRow = 5;
    m.toCol = 0;
    m.startMs = 0;
    m.durationMs = 500;
    m.piece = "wP";
    arbiter.startMotion(m);

    arbiter.resolveMoves(b, 500, registry);

    CHECK(b.grid[5][0] == "wP");
}

TEST_CASE("arrival onto a friendly-occupied destination leaves both pieces in place") {
    Board b = makeBoard({{"wR", "wP"}});
    RealTimeArbiter arbiter;
    PieceMove m;
    m.fromRow = 0; m.fromCol = 0; m.toRow = 0; m.toCol = 1;
    m.startMs = 0; m.durationMs = 500; m.piece = "wR";
    arbiter.startMotion(m);

    std::vector<std::string> captured = arbiter.resolveMoves(b, 500, registry);

    CHECK(captured.empty());
    CHECK(b.grid[0][0] == "wR"); // move failed - mover stayed at origin
    CHECK(b.grid[0][1] == "wP"); // friendly piece undisturbed
}

TEST_CASE("non-pawn piece is never modified by promotion check")
{
    Board b = makeBoard({{"."}, {"wR"}});
    RealTimeArbiter arbiter;
    PieceMove m;
    m.fromRow = 1;
    m.fromCol = 0;
    m.toRow = 0;
    m.toCol = 0;
    m.startMs = 0;
    m.durationMs = 500;
    m.piece = "wR";
    arbiter.startMotion(m);

    arbiter.resolveMoves(b, 500, registry);

    CHECK(b.grid[0][0] == "wR");
}

TEST_CASE("pawn promotion applies when arrival is a capture")
{
    Board b = makeBoard({{"bK"}, {"wP"}});
    RealTimeArbiter arbiter;
    PieceMove m;
    m.fromRow = 1;
    m.fromCol = 0;
    m.toRow = 0;
    m.toCol = 0;
    m.startMs = 0;
    m.durationMs = 500;
    m.piece = "wP";
    arbiter.startMotion(m);

    std::vector<std::string> captured = arbiter.resolveMoves(b, 500, registry);

    CHECK(captured.size() == 1);
    CHECK(captured[0] == "bK");
    CHECK(b.grid[0][0] == "wQ");
}
TEST_CASE("hasActiveJumpAt is true right after startJump and false once it lands untouched")
{
    Board b = makeBoard({{"bR"}});
    RealTimeArbiter arbiter;
    JumpMove j;
    j.row = 0; j.col = 0; j.startMs = 0; j.durationMs = 1000; j.piece = "bR";
    arbiter.startJump(j);

    CHECK(arbiter.hasActiveJumpAt(0, 0));

    arbiter.resolveMoves(b, 1000, registry);

    CHECK_FALSE(arbiter.hasActiveJumpAt(0, 0));
    CHECK(b.grid[0][0] == "bR"); // the piece never moved, board untouched
}

TEST_CASE("airborne piece captures an enemy that arrives during the jump window")
{
    // Locks the core "defense" rule: the arriving enemy is removed, the
    // jumper stays exactly where it was.
    Board b = makeBoard({{"bR", "wR"}});
    RealTimeArbiter arbiter;
    JumpMove j;
    j.row = 0; j.col = 0; j.startMs = 0; j.durationMs = 1000; j.piece = "bR";
    arbiter.startJump(j);

    PieceMove m;
    m.fromRow = 0; m.fromCol = 1; m.toRow = 0; m.toCol = 0;
    m.startMs = 0; m.durationMs = 500; m.piece = "wR";
    arbiter.startMotion(m);

    std::vector<std::string> captured = arbiter.resolveMoves(b, 500, registry);

    REQUIRE(captured.size() == 1);
    CHECK(captured[0] == "wR");
    CHECK(b.grid[0][0] == "bR"); // the airborne piece did not move
    CHECK(b.grid[0][1] == "."); // the arriving enemy was removed from its origin
}

TEST_CASE("a jump does not defend against an arriving friendly piece")
{
    // Locks: "only an enemy jump defends" - same color just blocks normally.
    Board b = makeBoard({{"bR", "bQ"}});
    RealTimeArbiter arbiter;
    JumpMove j;
    j.row = 0; j.col = 0; j.startMs = 0; j.durationMs = 1000; j.piece = "bR";
    arbiter.startJump(j);

    PieceMove m;
    m.fromRow = 0; m.fromCol = 1; m.toRow = 0; m.toCol = 0;
    m.startMs = 0; m.durationMs = 500; m.piece = "bQ";
    arbiter.startMotion(m);

    std::vector<std::string> captured = arbiter.resolveMoves(b, 500, registry);

    CHECK(captured.empty());
    CHECK(b.grid[0][0] == "bR"); // still the jumping rook, undisturbed
    CHECK(b.grid[0][1] == "bQ"); // the friendly mover stayed at its origin - move failed
}

TEST_CASE("a jump that receives no enemy lands normally with the board unchanged")
{
    Board b = makeBoard({{"bR"}});
    RealTimeArbiter arbiter;
    JumpMove j;
    j.row = 0; j.col = 0; j.startMs = 0; j.durationMs = 1000; j.piece = "bR";
    arbiter.startJump(j);

    arbiter.resolveMoves(b, 1000, registry);

    CHECK_FALSE(arbiter.hasActiveJumpAt(0, 0));
    CHECK(b.grid[0][0] == "bR");
}

